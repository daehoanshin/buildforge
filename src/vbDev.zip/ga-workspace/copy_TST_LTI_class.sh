 mkdir -p "/pgms/online/appls/node/LTI/LTI.war/WEB-INF/classes/del /F BM/SHL/UM.java"
 scp LTI:/pgms/online/appls/node/LTI/LTI.war/WEB-INF/classes/del /F BM/SHL/UM.class/del /F BM/SHL/UM*.class /pgms/online/appls/node/LTI/LTI.war/WEB-INF/classes/del /F BM/SHL/UM.java/
