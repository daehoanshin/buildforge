echo  mkdir -p /webroot/dinle/nxui/lti/abc/test.xfdl.js
 mkdir -p /webroot/dinle/nxui/lti/abc/test.xfdl.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/lti/abc/test.xfdl.js'" "/webroot/dinle/nxui/lti/abc/test.xfdl.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/lti/abc/test.xfdl.js'" "/webroot/dinle/nxui/lti/abc/test.xfdl.js"
echo  mkdir -p /webroot/dinle/nxui/frame/US.xfdl.js
 mkdir -p /webroot/dinle/nxui/frame/US.xfdl.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/frame/US.xfdl.js'" "/webroot/dinle/nxui/frame/US.xfdl.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/frame/US.xfdl.js'" "/webroot/dinle/nxui/frame/US.xfdl.js"
echo  mkdir -p /webroot/dinle/nxui/tcm/UM.xfdl.js
 mkdir -p /webroot/dinle/nxui/tcm/UM.xfdl.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/tcm/UM.xfdl.js'" "/webroot/dinle/nxui/tcm/UM.xfdl.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/tcm/UM.xfdl.js'" "/webroot/dinle/nxui/tcm/UM.xfdl.js"
echo  mkdir -p /webroot/dinle/nxui/images/UI2.gif
 mkdir -p /webroot/dinle/nxui/images/UI2.gif
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/images/UI2.gif'" "/webroot/dinle/nxui/images/UI2.gif"
 scp 10.10.20.21:"'/webroot/dinle/nxui/images/UI2.gif'" "/webroot/dinle/nxui/images/UI2.gif"
echo  mkdir -p /webroot/dinle/nxui/font/font.ttf
 mkdir -p /webroot/dinle/nxui/font/font.ttf
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/font/font.ttf'" "/webroot/dinle/nxui/font/font.ttf"
 scp 10.10.20.21:"'/webroot/dinle/nxui/font/font.ttf'" "/webroot/dinle/nxui/font/font.ttf"
echo  mkdir -p /webroot/dinle/nxui/home.html
 mkdir -p /webroot/dinle/nxui/home.html
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/home.html'" "/webroot/dinle/nxui/home.html"
 scp 10.10.20.21:"'/webroot/dinle/nxui/home.html'" "/webroot/dinle/nxui/home.html"
echo  mkdir -p /webroot/install_nexacro/file.dll.js
 mkdir -p /webroot/install_nexacro/file.dll.js
echo  scp 10.10.20.21:"'/webroot/install_nexacro/file.dll.js'" "/webroot/install_nexacro/file.dll.js"
 scp 10.10.20.21:"'/webroot/install_nexacro/file.dll.js'" "/webroot/install_nexacro/file.dll.js"
echo  mkdir -p /webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js
 mkdir -p /webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js'" "/webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js'" "/webroot/dinle/nxui/ltl/bde/etf/ab9010.xfdl.js"
echo  mkdir -p /webroot/install_nexacro/install.exe.js
 mkdir -p /webroot/install_nexacro/install.exe.js
echo  scp 10.10.20.21:"'/webroot/install_nexacro/install.exe.js'" "/webroot/install_nexacro/install.exe.js"
 scp 10.10.20.21:"'/webroot/install_nexacro/install.exe.js'" "/webroot/install_nexacro/install.exe.js"
echo  mkdir -p /webroot/dinle/nxui/css/stylesheet.css.js
 mkdir -p /webroot/dinle/nxui/css/stylesheet.css.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/css/stylesheet.css.js'" "/webroot/dinle/nxui/css/stylesheet.css.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/css/stylesheet.css.js'" "/webroot/dinle/nxui/css/stylesheet.css.js"
echo  mkdir -p /webroot/dinle/nxui/_theme_/theme.css
 mkdir -p /webroot/dinle/nxui/_theme_/theme.css
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/_theme_/theme.css'" "/webroot/dinle/nxui/_theme_/theme.css"
 scp 10.10.20.21:"'/webroot/dinle/nxui/_theme_/theme.css'" "/webroot/dinle/nxui/_theme_/theme.css"
echo  mkdir -p /webroot/dinle/nxui/web/hello.html
 mkdir -p /webroot/dinle/nxui/web/hello.html
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/web/hello.html'" "/webroot/dinle/nxui/web/hello.html"
 scp 10.10.20.21:"'/webroot/dinle/nxui/web/hello.html'" "/webroot/dinle/nxui/web/hello.html"
echo  mkdir -p /webroot/dinle/nxui/web/helloJs.js
 mkdir -p /webroot/dinle/nxui/web/helloJs.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/web/helloJs.js'" "/webroot/dinle/nxui/web/helloJs.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/web/helloJs.js'" "/webroot/dinle/nxui/web/helloJs.js"
echo  mkdir -p /webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js
 mkdir -p /webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js
echo  scp 10.10.20.21:"'/webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js'" "/webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js"
 scp 10.10.20.21:"'/webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js'" "/webroot/dinle/nxui/nexacro14lib/component/CompBase/baseframe.js"
